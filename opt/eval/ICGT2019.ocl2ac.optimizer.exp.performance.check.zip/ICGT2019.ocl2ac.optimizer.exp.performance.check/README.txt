1. Please set the path of the project to the field projectPathName in the class configure.
2. Run the executable classes as java application.