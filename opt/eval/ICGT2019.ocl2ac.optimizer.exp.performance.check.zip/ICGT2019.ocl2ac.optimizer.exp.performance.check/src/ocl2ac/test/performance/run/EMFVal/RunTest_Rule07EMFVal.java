package ocl2ac.test.performance.run.EMFVal;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;
import ocl2ac.test.performance.run.RunTest_EMFValidator;
import ocl2ac.test.performance.run.Rules.RunTest_Rule07;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule07EMFVal {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	private static final String DASHPREFIX = "- ";

	public static EObject root = null;
	public static String printInfo = null;
	public static String INSTANCE_FILE_PATH_NAME = null;

	public static void main(String[] args) {

		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.INSTANCEFILEPATHNAME_10096;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The model is initialized.");
		}

		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
	
		// Apply the original rule
		RunTest_Rule07.root = root;
		RunTest_Rule07.main(null);
		String newline = System.lineSeparator();

		// Validate using the EMF validator
		RunTest_EMFValidator.root = root;
		RunTest_EMFValidator.main(null);

		long sum = RunTest_Rule07.exeTime + RunTest_EMFValidator.exeTime;
		printInfo = DASHPREFIX + RunTest_Rule07.exeTime + "+" + RunTest_EMFValidator.exeTime + "=" + sum ;
		System.out.println(printInfo+ " ms");

		root = null;
		INSTANCE_FILE_PATH_NAME = null;

	}

}
