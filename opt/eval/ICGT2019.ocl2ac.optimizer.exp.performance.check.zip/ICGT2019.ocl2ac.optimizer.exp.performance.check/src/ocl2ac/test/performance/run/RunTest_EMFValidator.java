package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import ocl2ac.test.performance.core.EMFValidator;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_EMFValidator {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	public static EObject root = null;
	public static String printInfo = null;
	public static long exeTime = 0;
	public static boolean emfVal;

	public static void main(String[] args) {
		printInfo = null;
		exeTime = 0;
		// Check validity using the EMF validator
		emfVal = EMFValidator.evaluate(root);
		exeTime = EMFValidator.evaluationTime;
		printInfo = emfVal + ", " + exeTime + " ms";
	}
}
