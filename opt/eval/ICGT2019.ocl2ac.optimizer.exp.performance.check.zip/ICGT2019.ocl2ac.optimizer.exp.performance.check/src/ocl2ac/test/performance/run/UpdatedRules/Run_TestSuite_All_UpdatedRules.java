package ocl2ac.test.performance.run.UpdatedRules;

import ocl2ac.configure.Configure;

public class Run_TestSuite_All_UpdatedRules {
	private static final int MAX = 100;

	public static void main(String[] args) {

		// You can change the model size from here
		String instancePathName = Configure.INSTANCEFILEPATHNAME_03368;

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule01.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule01.main(null);

		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule02.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule02.main(null);

		}

		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule03.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule03.main(null);

		}

		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule04.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule04.main(null);

		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule05.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule05.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule06.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule06.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule07.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule07.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule08.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule08.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule09.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule09.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule10.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule10.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule11.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule11.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule12.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule12.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule13.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule13.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule14.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule14.main(null);
		}
		System.out.println(
				"=================================================================================================");
		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedRule15.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedRule15.main(null);
		}
		System.out.println(
				"=================================================================================================");
	}

}
