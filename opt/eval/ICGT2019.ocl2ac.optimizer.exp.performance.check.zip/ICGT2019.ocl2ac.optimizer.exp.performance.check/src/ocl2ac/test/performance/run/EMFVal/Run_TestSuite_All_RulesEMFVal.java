package ocl2ac.test.performance.run.EMFVal;

import ocl2ac.configure.Configure;

public class Run_TestSuite_All_RulesEMFVal {
	private static final int MAX = 100;

	public static void main(String[] args) {

		// You can change the model size from here
		String instancePathName = Configure.INSTANCEFILEPATHNAME_03368;

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule01EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule01EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule02EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule02EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule03EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule03EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule04EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule04EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule05EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule05EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule06EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule06EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule07EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule07EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule08EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule08EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule09EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule09EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule10EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule10EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule11EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule11EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule12EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule12EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule13EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule13EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule14EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule14EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule15EMFVal.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule15EMFVal.main(null);
		}
		System.out.println(
				"=================================================================================================");

	}

}
