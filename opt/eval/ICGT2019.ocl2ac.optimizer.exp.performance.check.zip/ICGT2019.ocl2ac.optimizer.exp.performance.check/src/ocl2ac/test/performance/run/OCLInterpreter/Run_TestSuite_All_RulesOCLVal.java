package ocl2ac.test.performance.run.OCLInterpreter;

import ocl2ac.configure.Configure;

public class Run_TestSuite_All_RulesOCLVal {
	private static final int MAX = 100;

	public static void main(String[] args) {

		// You can change the model size from here
		String instancePathName = Configure.INSTANCEFILEPATHNAME_03368;

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule01OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule01OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule02OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule02OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule03OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule03OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule04OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule04OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule05OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule05OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule06OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule06OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule07OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule07OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule08OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule08OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule09OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule09OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule10OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule10OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule11OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule11OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule12OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule12OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule13OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule13OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule14OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule14OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_Rule15OCLInterpreter.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_Rule15OCLInterpreter.main(null);
		}
		System.out.println(
				"=================================================================================================");

	}

}
