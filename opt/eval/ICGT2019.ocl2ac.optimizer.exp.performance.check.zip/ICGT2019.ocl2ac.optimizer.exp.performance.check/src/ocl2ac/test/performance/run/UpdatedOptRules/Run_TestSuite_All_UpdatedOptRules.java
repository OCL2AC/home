package ocl2ac.test.performance.run.UpdatedOptRules;

import ocl2ac.configure.Configure;

public class Run_TestSuite_All_UpdatedOptRules {
	private static final int MAX = 100;

	public static void main(String[] args) {

		// You can change the model size from here
		String instancePathName = Configure.INSTANCEFILEPATHNAME_03368;

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule01.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule01.main(null);
		}

		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule02.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule02.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule03.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule03.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule04.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule04.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule05.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule05.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule06.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule06.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule07.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule07.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule08.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule08.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule09.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule09.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule10.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule10.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule11.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule11.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule12.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule12.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule13.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule13.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule14.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule14.main(null);
		}
		System.out.println(
				"=================================================================================================");

		for (int i = 0; i < MAX; i++) {
			RunTest_UpdatedOptRule15.INSTANCE_FILE_PATH_NAME = instancePathName;
			RunTest_UpdatedOptRule15.main(null);
		}
		System.out.println(
				"=================================================================================================");

	}

}
