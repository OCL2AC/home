package ocl2ac.test.performance.run.Rules;

import java.util.List;
import java.util.Random;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.Match;
import org.eclipse.emf.henshin.interpreter.UnitApplication;
import org.eclipse.emf.henshin.model.HenshinFactory;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule13 {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	private static final String OLD_TARGET = "OldTarget";
	private static final String SELECTED = "Selected";
	public static final String RULENAME = "removeFromConnectionPointReference_exit_Pseudostate";
	public static String INSTANCE_FILE_PATH_NAME = null;
	public static EObject root = null;
	public static String printInfo = null;
	public static long exeTime = 0;
	public static boolean applicable;

	public static void main(String[] args) {
		printInfo = null;
		exeTime = 0;

		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.INSTANCEFILEPATHNAME_10096;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}

		// Get the model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);

		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.HENSHINFILEPATHNAME_RULE13,
				RULENAME, root);

		List<Match> lhsMatches = NasHenshinManager.getLHSMatches(Configure.HENSHINFILEPATHNAME_RULE13, RULENAME, root);
		Random r = new Random();
		int low = 0;
		int high = lhsMatches.size();
		int i = r.nextInt(high - low) + low;
		unitApplication.setParameterValue(SELECTED,
				lhsMatches.get(i).getParameterValue(HenshinFactory.eINSTANCE.createParameter(SELECTED)));
		unitApplication.setParameterValue(OLD_TARGET,
				lhsMatches.get(i).getParameterValue(HenshinFactory.eINSTANCE.createParameter(OLD_TARGET)));

		// Apply the original rule
		long rule12_start = System.currentTimeMillis();
		applicable = unitApplication.execute(null);
		long rule12_stop = System.currentTimeMillis();

		// Calculate the time
		exeTime = rule12_stop - rule12_start;
		System.out.println("- The rule application took: " + exeTime + " ms");
	}

}
