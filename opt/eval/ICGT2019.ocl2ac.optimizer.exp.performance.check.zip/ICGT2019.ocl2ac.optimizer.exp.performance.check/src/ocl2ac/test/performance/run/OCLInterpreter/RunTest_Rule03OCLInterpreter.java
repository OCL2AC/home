package ocl2ac.test.performance.run.OCLInterpreter;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;
import ocl2ac.test.performance.run.RunTest_OCLEval;
import ocl2ac.test.performance.run.Rules.RunTest_Rule03;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule03OCLInterpreter {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	private static final String DASHPREFIX = "- ";

	public static EObject root = null;
	public static String printInfo = null;
	public static String INSTANCE_FILE_PATH_NAME = null;

	public static void main(String[] args) {

		int size = 0;

		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.INSTANCEFILEPATHNAME_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The model is initialized.");
		}

		// Get the model size
		size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
		
		// Apply the original rule
		RunTest_Rule03.root = root;
		RunTest_Rule03.main(null);
		String newline = System.lineSeparator();

		// Validate using the OCL interpreter
		RunTest_OCLEval.root = root;
		RunTest_OCLEval.main(null);

		// Calculate the sum
		long sum = RunTest_Rule03.exeTime + RunTest_OCLEval.exeTime;
		printInfo = DASHPREFIX + RunTest_Rule03.exeTime + "+" + RunTest_OCLEval.exeTime + "=" + sum;
		System.out.println(printInfo+ " ms");

		root = null;
		INSTANCE_FILE_PATH_NAME = null;

	}

}
