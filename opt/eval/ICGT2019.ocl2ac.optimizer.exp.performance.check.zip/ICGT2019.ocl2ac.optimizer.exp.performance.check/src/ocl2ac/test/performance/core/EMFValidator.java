package ocl2ac.test.performance.core;

import org.eclipse.emf.ecore.EObject;

import nas.core.NasEMFManager;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class EMFValidator {

	public static long evaluationTime = 0;

	public static boolean evaluate(EObject model) {

		// Calculate the evaluation time
		long start = System.currentTimeMillis();
		boolean valid = NasEMFManager.isValid(model);
		long end = System.currentTimeMillis();
		long dif = end - start;

		evaluationTime = dif;
		return valid;
	}
}
