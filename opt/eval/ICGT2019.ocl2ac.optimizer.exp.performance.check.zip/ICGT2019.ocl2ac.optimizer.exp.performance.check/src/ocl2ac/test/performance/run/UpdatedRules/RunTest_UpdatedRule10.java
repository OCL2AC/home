package ocl2ac.test.performance.run.UpdatedRules;

import java.util.List;
import java.util.Random;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.Match;
import org.eclipse.emf.henshin.interpreter.UnitApplication;
import org.eclipse.emf.henshin.model.HenshinFactory;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_UpdatedRule10 {

	private static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	private static final String SELECTED = "Selected";
	private static final String NEWSOURCE = "NewSource";
	private static final String OLDSOURCE = "OldSource";

	public static final String RULENAME = "moveFinalState_FROM_Region_subvertex_TO_Region_Region";
	public static String INSTANCE_FILE_PATH_NAME = null;
	public static EObject root = null;
	public static String printInfo = null;

	public static long diff = 0;

	public static void main(String[] args) {
		diff = 0;
		printInfo = null;

		// Load the model
		if (INSTANCE_FILE_PATH_NAME == null)
			INSTANCE_FILE_PATH_NAME = Configure.INSTANCEFILEPATHNAME_13460;
		Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
		root = (EObject) resource.getContents().get(0);

		// Get the model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model is initialized. The model size: " + size);
	
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager
				.prepareUnitApplication(Configure.HENSHINFILEPATHNAME_RULE10UPDATED, RULENAME, root);

		List<Match> lhsMatches = NasHenshinManager.getLHSMatches(Configure.HENSHINFILEPATHNAME_RULE10, RULENAME, root);
		Random r = new Random();
		int low = 0;
		int high = lhsMatches.size();
		int i = r.nextInt(high - low) + low;
		unitApplication.setParameterValue(OLDSOURCE,
				lhsMatches.get(i).getParameterValue(HenshinFactory.eINSTANCE.createParameter(OLDSOURCE)));
		unitApplication.setParameterValue(SELECTED,
				lhsMatches.get(i).getParameterValue(HenshinFactory.eINSTANCE.createParameter(SELECTED)));
		unitApplication.setParameterValue(NEWSOURCE,
				lhsMatches.get(i).getParameterValue(HenshinFactory.eINSTANCE.createParameter(NEWSOURCE)));

		// Apply the original rule
		long start = System.currentTimeMillis();
		boolean ruleAppRes = unitApplication.execute(null);
		long stop = System.currentTimeMillis();

		// Calculate the needed time
		diff = stop - start;
		System.out.println("- The rule application took: " + diff + " ms");
	}

}
