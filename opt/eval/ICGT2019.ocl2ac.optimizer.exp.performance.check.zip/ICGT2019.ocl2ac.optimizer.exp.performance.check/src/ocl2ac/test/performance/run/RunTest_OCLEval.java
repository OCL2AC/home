package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import ocl2ac.configure.Configure;
import ocl2ac.test.performance.core.OCLInterpreter;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_OCLEval {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	public static EObject root = null;
	public static String printInfo = null;
	public static long exeTime = 0;
	public static Boolean oclEval;

	public static void main(String[] args) {
		printInfo = null;
		exeTime = 0;
		// Check validity using the OCL interpreter
		Object oclEvalResult = OCLInterpreter.evaluateOCLonModel(root, ePackageInstance, Configure.OCLASFILEPATHNAME);
		oclEval = (Boolean) oclEvalResult;
		exeTime = OCLInterpreter.evaluationTime;
		printInfo = oclEval + ", " + exeTime + " ms";
		
	}

}
