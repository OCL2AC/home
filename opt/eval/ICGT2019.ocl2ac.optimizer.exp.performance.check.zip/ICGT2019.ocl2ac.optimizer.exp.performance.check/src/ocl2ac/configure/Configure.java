package ocl2ac.configure;

import java.util.Arrays;
import java.util.List;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class Configure {

	// The projectPathName is the field that has to be set by you regarding the
	// path of the
	// project on your PC
	public static final String PROJECTPATHNAME = "D:/projects/ws/ICGT2019.ocl2ac.optimizer.exp.performance.check"; 

	public static final String OCLASFILEPATHNAME = PROJECTPATHNAME + "/model/MagicDrawStatechartsEffective.ecore.oclas";
	// The path of the main folder for the performance test
	public static final String EVALDIRPATHNAME = PROJECTPATHNAME + "/eval";

	// Paths of the original rules
	public static final String HENSHINFILEPATHNAME_RULE01 = EVALDIRPATHNAME + "/rule01.henshin";
	public static final String HENSHINFILEPATHNAME_RULE02 = EVALDIRPATHNAME + "/rule02.henshin";
	public static final String HENSHINFILEPATHNAME_RULE03 = EVALDIRPATHNAME + "/rule03.henshin";
	public static final String HENSHINFILEPATHNAME_RULE04 = EVALDIRPATHNAME + "/rule04.henshin";
	public static final String HENSHINFILEPATHNAME_RULE05 = EVALDIRPATHNAME + "/rule05.henshin";
	public static final String HENSHINFILEPATHNAME_RULE06 = EVALDIRPATHNAME + "/rule06.henshin";
	public static final String HENSHINFILEPATHNAME_RULE07 = EVALDIRPATHNAME + "/rule07.henshin";
	public static final String HENSHINFILEPATHNAME_RULE08 = EVALDIRPATHNAME + "/rule08.henshin";
	public static final String HENSHINFILEPATHNAME_RULE09 = EVALDIRPATHNAME + "/rule09.henshin";
	public static final String HENSHINFILEPATHNAME_RULE10 = EVALDIRPATHNAME + "/rule10.henshin";
	public static final String HENSHINFILEPATHNAME_RULE11 = EVALDIRPATHNAME + "/rule11.henshin";
	public static final String HENSHINFILEPATHNAME_RULE12 = EVALDIRPATHNAME + "/rule12.henshin";
	public static final String HENSHINFILEPATHNAME_RULE13 = EVALDIRPATHNAME + "/rule13.henshin";
	public static final String HENSHINFILEPATHNAME_RULE14 = EVALDIRPATHNAME + "/rule14.henshin";
	public static final String HENSHINFILEPATHNAME_RULE15 = EVALDIRPATHNAME + "/rule15.henshin";

	// Paths of the updated rules
	public static final String HENSHINFILEPATHNAME_RULE01UPDATED = EVALDIRPATHNAME + "/rule01_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE02UPDATED = EVALDIRPATHNAME + "/rule02_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE03UPDATED = EVALDIRPATHNAME + "/rule03_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE04UPDATED = EVALDIRPATHNAME + "/rule04_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE05UPDATED = EVALDIRPATHNAME + "/rule05_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE06UPDATED = EVALDIRPATHNAME + "/rule06_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE07UPDATED = EVALDIRPATHNAME + "/rule07_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE08UPDATED = EVALDIRPATHNAME + "/rule08_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE09UPDATED = EVALDIRPATHNAME + "/rule09_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE10UPDATED = EVALDIRPATHNAME + "/rule10_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE11UPDATED = EVALDIRPATHNAME + "/rule11_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE12UPDATED = EVALDIRPATHNAME + "/rule12_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE13UPDATED = EVALDIRPATHNAME + "/rule13_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE14UPDATED = EVALDIRPATHNAME + "/rule14_updated.henshin";
	public static final String HENSHINFILEPATHNAME_RULE15UPDATED = EVALDIRPATHNAME + "/rule15_updated.henshin";

	// Paths of the updated optimized rules
	public static final String HENSHINFILEPATHNAME_RULE01UPDATEDOPT = EVALDIRPATHNAME + "/rule01_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE02UPDATEDOPT = EVALDIRPATHNAME + "/rule02_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE03UPDATEDOPT = EVALDIRPATHNAME + "/rule03_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE04UPDATEDOPT = EVALDIRPATHNAME + "/rule04_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE05UPDATEDOPT = EVALDIRPATHNAME + "/rule05_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE06UPDATEDOPT = EVALDIRPATHNAME + "/rule06_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE07UPDATEDOPT = EVALDIRPATHNAME + "/rule07_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE08UPDATEDOPT = EVALDIRPATHNAME + "/rule08_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE09UPDATEDOPT = EVALDIRPATHNAME + "/rule09_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE10UPDATEDOPT = EVALDIRPATHNAME + "/rule10_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE11UPDATEDOPT = EVALDIRPATHNAME + "/rule11_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE12UPDATEDOPT = EVALDIRPATHNAME + "/rule12_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE13UPDATEDOPT = EVALDIRPATHNAME + "/rule13_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE14UPDATEDOPT = EVALDIRPATHNAME + "/rule14_updated_opt.henshin";
	public static final String HENSHINFILEPATHNAME_RULE15UPDATEDOPT = EVALDIRPATHNAME + "/rule15_updated_opt.henshin";

	// Paths of the test models
	public static final String INSTANCEFILEPATHNAME_00845 = EVALDIRPATHNAME + "/My_00845.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_01686 = EVALDIRPATHNAME + "/My_01686.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_03368 = EVALDIRPATHNAME + "/My_03368.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_06732 = EVALDIRPATHNAME + "/My_06732.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_10096 = EVALDIRPATHNAME + "/My_10096.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_13460 = EVALDIRPATHNAME + "/My_13460.magicdrawstatechartseffective";
	public static final String INSTANCEFILEPATHNAME_16824 = EVALDIRPATHNAME + "/My_16824.magicdrawstatechartseffective";

	public static final List<String> INSTANCESLIST = Arrays.asList(INSTANCEFILEPATHNAME_00845,
			INSTANCEFILEPATHNAME_01686, INSTANCEFILEPATHNAME_03368, INSTANCEFILEPATHNAME_06732,
			INSTANCEFILEPATHNAME_10096, INSTANCEFILEPATHNAME_13460, INSTANCEFILEPATHNAME_16824);
}
