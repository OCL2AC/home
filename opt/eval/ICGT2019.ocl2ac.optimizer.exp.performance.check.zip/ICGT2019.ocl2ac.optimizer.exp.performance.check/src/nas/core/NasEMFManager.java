package nas.core;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.ocl.ecore.OCL;
import org.eclipse.ocl.pivot.internal.delegate.OCLDelegateDomain;
import org.eclipse.ocl.pivot.model.OCLstdlib;
import org.eclipse.ocl.xtext.essentialocl.EssentialOCLStandaloneSetup;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */

public class NasEMFManager {

	/**
	 * 
	 * @param instanceFilePathName
	 * @param ePackage
	 * @return
	 */
	public static Resource loadModel(String instanceFilePathName, EPackage ePackage) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		resourceSet.getPackageRegistry().put(ePackage.getNsURI(), ePackage);
		URI instanceFileUri = URI.createFileURI(instanceFilePathName);
		Resource resource = resourceSet.getResource(instanceFileUri, true);
		return resource;
	}

	/**
	 * @param instance
	 * @return
	 */
	public static boolean isValid(EObject instance) {
		OCL.initialize(null);
		OCLDelegateDomain.initialize(null);
		EssentialOCLStandaloneSetup.doSetup();
		OCLstdlib.install();
		Diagnostician diagnostician = new Diagnostician();
		Diagnostic diagnostic = diagnostician.validate(instance);
		switch (diagnostic.getSeverity()) {
		case Diagnostic.OK:
			return true;
		case Diagnostic.ERROR:
			System.err.println("Error");
			for (Diagnostic d : diagnostic.getChildren())
				System.out.println(d.getMessage());
			System.out.println();
			return false;
		}
		return false;
	}

}
