package nas.core;

import java.util.List;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.henshin.interpreter.EGraph;
import org.eclipse.emf.henshin.interpreter.Engine;
import org.eclipse.emf.henshin.interpreter.Match;
import org.eclipse.emf.henshin.interpreter.UnitApplication;
import org.eclipse.emf.henshin.interpreter.impl.EGraphImpl;
import org.eclipse.emf.henshin.interpreter.impl.EngineImpl;
import org.eclipse.emf.henshin.interpreter.impl.UnitApplicationImpl;
import org.eclipse.emf.henshin.interpreter.util.InterpreterUtil;
import org.eclipse.emf.henshin.model.HenshinPackage;
import org.eclipse.emf.henshin.model.Module;
import org.eclipse.emf.henshin.model.Rule;
import org.eclipse.emf.henshin.model.Unit;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class NasHenshinManager {

	/**
	 * 
	 * @param ruleName
	 * @param root
	 * @return
	 */
	public static UnitApplication prepareUnitApplication(String henshinFilePathName, String ruleName, EObject root) {
		HenshinPackage.eINSTANCE.eClass();
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		URI henFileUri = URI.createFileURI(henshinFilePathName);
		Resource henResource = resourceSet.getResource(henFileUri, true);
		Module module = (Module) henResource.getContents().get(0);
		EGraph graph = new EGraphImpl(root);
		Engine engine = new EngineImpl();
		Unit mainUnit = module.getUnit(ruleName);
		UnitApplication mainUnitApplication = new UnitApplicationImpl(engine, graph, mainUnit, null);

		return mainUnitApplication;
	}

	/**
	 * 
	 * @param ruleName
	 * @param root
	 * @return
	 */
	public static List<Match> getLHSMatches(String henshinFilePathName, String ruleName, EObject root) {
		HenshinPackage.eINSTANCE.eClass();
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		URI henFileUri = URI.createFileURI(henshinFilePathName);
		Resource henResource = resourceSet.getResource(henFileUri, true);
		Module module = (Module) henResource.getContents().get(0);
		EGraph graph = new EGraphImpl(root);
		Engine engine = new EngineImpl();
		engine.getOptions().put(Engine.OPTION_DETERMINISTIC, false);
		Unit mainUnit = module.getUnit(ruleName);
		Rule mainRule = (Rule) mainUnit;
		if (mainRule.getLhs().getFormula() != null) {
			mainRule.getLhs().setFormula(null);
		}
		Rule ruleWithoutAC = mainRule;
		ruleWithoutAC.setName("ruleWithoutAC");
		return InterpreterUtil.findAllMatches(engine, ruleWithoutAC, graph, null);

	}

	/**
	 * 
	 * @param instanceFilePathName
	 * @param ePackage
	 * @return
	 */
	public static Resource loadModel(String instanceFilePathName, EPackage ePackage) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		resourceSet.getPackageRegistry().put(ePackage.getNsURI(), ePackage);
		URI instanceFileUri = URI.createFileURI(instanceFilePathName);
		Resource resource = resourceSet.getResource(instanceFileUri, true);
		return resource;
	}

	/**
	 * 
	 * @param instanceFilePathName
	 * @param ePackage
	 * @return
	 */
	public static Resource loadHenshinFile(String instanceFilePathName) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		resourceSet.getPackageRegistry().put(HenshinPackage.eINSTANCE.getNsURI(), HenshinPackage.eINSTANCE);
		URI instanceFileUri = URI.createFileURI(instanceFilePathName);
		Resource resource = resourceSet.getResource(instanceFileUri, true);
		return resource;
	}

	/**
	 * 
	 * @param root
	 * @return
	 */
	public static int getModelSize(EObject root) {
		EGraph graph = new EGraphImpl(root);
		int numNodes = graph.size();
		int numEdges = InterpreterUtil.countEdges(graph);
		int size = numNodes + numEdges;
		return size;
	}

}
