package nas.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.ocl.OCL;
import org.eclipse.ocl.ParserException;
import org.eclipse.ocl.ecore.Constraint;
import org.eclipse.ocl.ecore.EcoreEnvironmentFactory;
import org.eclipse.ocl.expressions.OCLExpression;
import org.eclipse.ocl.helper.OCLHelper;
import org.eclipse.ocl.pivot.Class;
import org.eclipse.ocl.pivot.ExpressionInOCL;
import org.eclipse.ocl.pivot.LanguageExpression;
import org.eclipse.ocl.pivot.Model;
import org.eclipse.ocl.pivot.PivotPackage;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class NasOCLManager {
	private static final OCL<?, EClassifier, ?, ?, ?, ?, ?, ?, ?, Constraint, EClass, EObject> ocl = OCL
			.newInstance(EcoreEnvironmentFactory.INSTANCE);
	private static final OCLHelper<EClassifier, ?, ?, Constraint> helper = ocl.createOCLHelper();
	private static HashMap<EClass, ArrayList<String>> mapConstraints = new HashMap<EClass, ArrayList<String>>();

	public static Object evaluateOCLOnContextObject(EObject contextObject, String expression) {
		if (contextObject == null)
			return null;
		try {
			helper.setContext(contextObject.eClass());
			OCLExpression<EClassifier> query = helper.createQuery(expression);
			Object oclResult = ocl.evaluate(contextObject, query);
			return oclResult;
		} catch (ParserException e) {
			e.printStackTrace();
		}

		return null;

	}

	/**
	 * 
	 * @param oclasFilePathName
	 * @param typeModel
	 * @return
	 */
	public static HashMap<EClass, ArrayList<String>> getConstraintsInfo(String oclasFilePathName, EPackage typeModel) {
		mapConstraints.clear();
		Resource oclRes = loadModel(oclasFilePathName, PivotPackage.eINSTANCE);
		Model oclModel = (Model) oclRes.getContents().get(0);
		List<EObject> oclModelAsList = new ArrayList<EObject>();
		oclModel.eAllContents().forEachRemaining(oclModelAsList::add);
		for (Object o : EcoreUtil.getObjectsByType(oclModelAsList, PivotPackage.Literals.CONSTRAINT)) {
			org.eclipse.ocl.pivot.Constraint inv = (org.eclipse.ocl.pivot.Constraint) o;
			LanguageExpression languageExpression = inv.getOwnedSpecification();
			if (languageExpression instanceof ExpressionInOCL) {
				ExpressionInOCL expressionInOCL = (ExpressionInOCL) languageExpression;
				EClass key = getEClass(expressionInOCL.getOwnedContext().getType().isClass(), typeModel);
				if (key == null)
					return null;
				if (!mapConstraints.containsKey(key)) {
					ArrayList<String> arrayList = new ArrayList<String>();
					arrayList.add(expressionInOCL.getBody());
					mapConstraints.put(key, arrayList);
				} else {
					mapConstraints.get(key).add(expressionInOCL.getBody());
				}
			}
		}
		return mapConstraints;
	}

	/**
	 * 
	 * @param filePathName
	 * @param ePackage
	 * @return
	 */
	private static Resource loadModel(String filePathName, EPackage ePackage) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		resourceSet.getPackageRegistry().put(ePackage.getNsURI(), ePackage);
		URI instanceFileUri = URI.createFileURI(filePathName);
		Resource resource = resourceSet.getResource(instanceFileUri, true);
		return resource;
	}

	/**
	 * 
	 * @param clazz
	 * @param ePackage
	 * @return
	 */
	protected static EClass getEClass(Class clazz, EPackage ePackage) {
		for (EClassifier classifier : ePackage.getEClassifiers()) {
			if (classifier instanceof EClass && classifier.getName().equals(clazz.getName())) {
				return (EClass) classifier;
			}
		}
		return null;
	}

}
