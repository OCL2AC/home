package icgt2019.exp.complexity.integration.run;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.henshin.model.HenshinPackage;
import org.eclipse.emf.henshin.model.Module;
import org.eclipse.emf.henshin.model.Rule;
import org.eclipse.emf.henshin.model.Unit;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import de.unimarburg.swt.ocl2ac.automate.core.GC2AppCondCommand;
import nas.core.Configure;
import nas.core.NasHenshinManager;
import nestedcondition.NestedConstraint;
import nestedconstraintmodel.NestedConstraintModel;
import nestedconstraintmodel.NestedconstraintmodelPackage;

public class RunExpA_IntegrationWithoutOptimization {

	private static final String _UPDATED = "_updated";
	private static final String HENSHIN = ".henshin";

	public static void main(String[] args) {

		String expA_input = Configure.EXPA_INPUT_ALL;
		String expA_output = Configure.EXPA_OUTPUT_ALL;
		long integrationTotalTime = 0;
		File inputRulesDir = new File(expA_input).getAbsoluteFile();
		File[] henshinFiles = inputRulesDir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(HENSHIN);
			}
		});

		for (File henFile : henshinFiles) {
			Resource henResource = NasHenshinManager.loadHenshinFile(henFile.getAbsolutePath().toString());
			Module module = (Module) henResource.getContents().get(0);
			Resource constraintModelRes = NasHenshinManager.loadModel(Configure.NESTEDCONSTRAINTFILEPATHNAME,
					NestedconstraintmodelPackage.eINSTANCE);
			NestedConstraintModel nestedConstraintModel = (NestedConstraintModel) constraintModelRes.getContents()
					.get(0);
			MagicDrawStatechartsEffectivePackage.eINSTANCE.eClass();
			GC2AppCondCommand t = new GC2AppCondCommand();

			for (Unit unit : module.getUnits()) {
				if (unit instanceof Rule) {
					Rule rule = (Rule) unit;
					for (int i = 0; i < nestedConstraintModel.getNestedconstrainmodels().size(); i++) {
						NestedConstraint con = nestedConstraintModel.getNestedconstrainmodels().get(i);
						t.integrateAndleftInPlace(con, rule);
						integrationTotalTime += t.translationTime;

					}
				}
			}

			String newFileName = henFile.getName().replaceFirst(HENSHIN, _UPDATED + HENSHIN);
			persistHenshinFile(module, expA_output, newFileName);
		}
		System.out.println("integrationTotalTime:" + integrationTotalTime + " ms");
	}

	/**
	 * 
	 * @param module
	 * @param dirPathName
	 * @param henshinFileName
	 */
	private static void persistHenshinFile(Module module, String dirPathName, String henshinFileName) {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		resourceSet.getPackageRegistry().put(HenshinPackage.eINSTANCE.getNsURI(), HenshinPackage.eINSTANCE);
		URI updatedHenFileUri = URI.createFileURI(dirPathName.concat("/" + henshinFileName));
		Resource resource = resourceSet.createResource(updatedHenFileUri);
		resource.getContents().add(module);
		try {
			resource.save(null);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
