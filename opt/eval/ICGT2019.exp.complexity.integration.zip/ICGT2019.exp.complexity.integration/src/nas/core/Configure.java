package nas.core;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class Configure {
	// The projectPathName is the field that has to be set by you regarding the
	// path of the project on your PC
	// This is given as an example
	public static final String PROJECTPATHNAME = "D:/projects/ws/ICGT2019.exp.complexity.integration";

	public static final String EXPINPUTS_INPUT_ALL = PROJECTPATHNAME + "/ExpInputs/inputeditrules/all";
	public static final String EXPA_INPUT_ALL = PROJECTPATHNAME + "/ExpA/inputeditrules/all";
	public static final String EXPA_OUTPUT_ALL = PROJECTPATHNAME + "/ExpA/outputeditrules/all";
	public static final String EXPB_INPUT_ALL = PROJECTPATHNAME + "/ExpB/inputeditrules/all";
	public static final String EXPB_OUTPUT_ALL = PROJECTPATHNAME + "/ExpB/outputeditrules/all";
	public static final String NESTEDCONSTRAINTFILEPATHNAME = PROJECTPATHNAME
			+ "/model/MagicDrawStatechartsEffectiveConstraints.nestedconstraintmodel";
	public static final String OCLASFILEPATHNAME = PROJECTPATHNAME + "/model/MagicDrawStatechartsEffective.ecore.oclas";
}
