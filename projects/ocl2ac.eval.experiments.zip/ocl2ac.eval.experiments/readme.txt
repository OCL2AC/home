################# Info #################

- Be sure that the tool ocl2ac is installed in your Eclipse.
- Before executing the tests, please set the main path of the project ocl2ac.eval.experiments. Please take a look at the class Configure to set the needed path.
- All the performance and scalable tests are located in the package ocl2ac.test.performance.run 
- In the folder eval there are the inputs (rules and instances) of the testes and folders composing the corresponding outputs. The outputs of the tests (composing the information) are persisted as text files.
- In the folder integrator, you will see the inputs and outputs of integrating 11 OCL constraints into 5 rules. To the run the test again, run the main method of the class IntegratorTestRun. 


- All evaluations were performed with a desktop PC, Intel Core i7, 16 GB RAM,
Windows 7 x64, Eclipse Neon, Henshin 1.4.


For any question, please contact me:
Nebras Nassar
nassarn@mathematik.uni-marburg.de