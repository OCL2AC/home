package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule00 {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
	private static final String RULE_PARAM_SOURCE = "rv";
	private static final String RULE_PARAM_TARGET = "rt";
	public static final String ruleName = "insert_outgoing_transition";

	public static String INSTANCE_FILE_PATH_NAME = null;
	public static EObject root = null;
	public static String printInfo = null;
	public static long exeTime = 0;

	public static void main(String[] args) {
	
		printInfo = null;
		exeTime = 0;

		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}

		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
		System.out.println("=================================================================================================");

		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule00, ruleName, root);

		// Prepare the match for the rule
		EObject rule00_src = root.eContents().get(1).eContents().get(5);
		EObject rule00_tgt = root.eContents().get(1).eContents().get(4);
		unitApplication.setParameterValue(RULE_PARAM_SOURCE, rule00_src);
		unitApplication.setParameterValue(RULE_PARAM_TARGET, rule00_tgt);

		// Apply the rule
		long rule00_start = System.currentTimeMillis();
		boolean rule00_b = unitApplication.execute(null);
		long rule00_stop = System.currentTimeMillis();
		exeTime = rule00_stop - rule00_start;
		
		System.out.println("- The application of original rule: " + ruleName + " . Output is: " + rule00_b);
		System.out.println("- The rule application took: " + exeTime + " ms");
		printInfo = ruleName + ", " + rule00_b + ", " + exeTime + " ms";
		System.out.println("=================================================================================================");
	}

}
