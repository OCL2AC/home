package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_UpdatedRule07 {

	private static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	private static final String TO_BE_DELETED = "ToBeDeleted";
	private static final String SELECTED = "Selected";
	
	public static String ruleName = "rule07";
    public static String INSTANCE_FILE_PATH_NAME = null;
    public static EObject root =null;
	public static String printInfo=null;
    public static String fileDirPathName = Configure.evalUpdatedRuleDirPathName;

	
	public static void main(String[] args) {
		printInfo=null;
		String newline = System.lineSeparator();

		// Load the model
		if (INSTANCE_FILE_PATH_NAME == null) INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
		Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
		root = (EObject) resource.getContents().get(0);
		
		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The models are initialized. The model size: "+size);
		System.out.println("=================================================================================================");
		
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule07Updated, ruleName, root);
		
		// Prepare the match for the rule
		EObject rule07_src = root;
		EObject rule07_tgt = root.eContents().get(0);
		unitApplication.setParameterValue(SELECTED, rule07_src);
		unitApplication.setParameterValue(TO_BE_DELETED, rule07_tgt);
		
		// Apply the updated rule
		long start = System.currentTimeMillis();
		boolean ruleAppRes = unitApplication.execute(null);
		long stop = System.currentTimeMillis();
		
		// Calculate the needed time
		long diff = stop - start;
		System.out.println("- The application of updated rule: " + ruleName + " Output is: " + ruleAppRes);
		System.out.println("- The rule application took: " + diff + " ms");
		printInfo=ruleName+", "+ruleAppRes+", "+  diff + " ms";
		System.out.println("=================================================================================================");
		
		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_UpdatedRule_" + ruleName;
		nas.text.append("modelSize_" + size + newline);
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);
	}
}
