package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule00EMFVal {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	public static EObject root = null;
	public static String printInfo = null;
	public static String INSTANCE_FILE_PATH_NAME = null;
	private static final String DASHPREFIX = "- ";
    public static String fileDirPathName = Configure.evalRuleEMFDirPathName;

	public static void main(String[] args) {

		int size = 0;
		
		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");

		}

		// Get model size
		size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
		System.out.println("=================================================================================================");

		// Apply the original rule
		RunTest_Rule00.root = root;
		RunTest_Rule00.main(null);
		String newline = System.lineSeparator();
		printInfo = DASHPREFIX + RunTest_Rule00.printInfo + newline;

		// Validate using EMF validator
		RunTest_EMFValidator.root = root;
		RunTest_EMFValidator.main(null);
		printInfo += DASHPREFIX + RunTest_EMFValidator.printInfo + newline;
		
		// Calculate the sum
		long sum = RunTest_Rule00.exeTime + RunTest_EMFValidator.exeTime;
		printInfo += DASHPREFIX + RunTest_Rule00.exeTime + "+" + RunTest_EMFValidator.exeTime + "=" + sum + newline;
		System.out.println(printInfo);

		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_Rule_" + RunTest_Rule00.ruleName;
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);

	}

}
