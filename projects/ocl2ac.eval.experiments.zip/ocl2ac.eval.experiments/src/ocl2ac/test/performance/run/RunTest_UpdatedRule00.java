package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_UpdatedRule00 {

	private static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
	private static final String RULE_PARAM_SOURCE = "rv";
	private static final String RULE_PARAM_TARGET = "rt";

	public static String ruleName = "insert_outgoing_transition";
	public static String INSTANCE_FILE_PATH_NAME = null;
    public static EObject root =null;
    public static String printInfo=null;
    public static String fileDirPathName = Configure.evalUpdatedRuleDirPathName;

	public static void main(String[] args) {
		
		printInfo=null;
		String newline = System.lineSeparator();

		// Load the model
		if (INSTANCE_FILE_PATH_NAME == null) INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
		Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
		root = (EObject) resource.getContents().get(0);
		
		// Get the model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The models are initialized. The model size: "+size);
		System.out.println("=================================================================================================");
		
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule00Updated, ruleName, root);
		
		// Prepare the match for the rule
		EObject rule00_src = root.eContents().get(1).eContents().get(5);
		EObject rule00_tgt = root.eContents().get(1).eContents().get(4);
		unitApplication.setParameterValue(RULE_PARAM_SOURCE, rule00_src);
		unitApplication.setParameterValue(RULE_PARAM_TARGET, rule00_tgt);
		
		// Apply the updated rule
		long start = System.currentTimeMillis();
		boolean ruleAppRes = unitApplication.execute(null);
		long stop = System.currentTimeMillis();
		
		// Calculate the needed time
		long diff = stop - start;
		System.out.println("- The application of updated rule: " + ruleName + " . Output is: " + ruleAppRes);
		System.out.println("- The rule application took: " + diff + " ms");
		printInfo=ruleName+", "+ruleAppRes+", "+  diff + " ms";
		System.out.println("=================================================================================================");
		
		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_UpdatedRule_" + ruleName;
		nas.text.append("modelSize_" + size + newline);
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);	
	}
}
