package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;
import ocl2ac.test.performance.core.EMFValidator;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_EMFValidator {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
    public static EObject root =null;
    public static String printInfo=null;
    public static long exeTime=0;
	public static void main(String[] args) {
		printInfo=null;
		exeTime=0;
		
//		// Load model
//		if (root ==null){
//		Resource resource = NasEMFManager.loadModel(Configure.instanceFilePathName_00845, ePackageInstance);
//		root = (EObject) resource.getContents().get(0);
//		int size = NasHenshinManager.getModelSize(root);
//		System.out.println("The models are initialized. The model size: "+size);
//		System.out.println("=================================================================================================");
//		}
		
		// Check validity using the EMF validator
		boolean emfVal = EMFValidator.evaluate(root);
		System.out.println("- The output of the EMF validator is: "+emfVal );
		exeTime=EMFValidator.evaluationTime;
		System.out.println("- The EMF validator took: "+exeTime+" ms");		
		printInfo= emfVal+", "+exeTime+" ms";
		System.out.println("=================================================================================================");
	}
}
