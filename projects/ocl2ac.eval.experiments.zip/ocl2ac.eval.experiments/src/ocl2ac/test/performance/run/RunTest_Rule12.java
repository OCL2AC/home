package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule12 {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;

	private static final String OLD_TARGET = "OldTarget";
	private static final String SELECTED = "Selected";

	public static final String ruleName = "rule12";
	public static String INSTANCE_FILE_PATH_NAME = null;
	public static EObject root =null;
	public static String printInfo=null;
    public static long exeTime=0;
       
	public static void main(String[] args) {
		printInfo=null;
		exeTime=0;
		
		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}
		
		// Get the model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: "+size);
		System.out.println("=================================================================================================");
		
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule12, ruleName, root);
		
		// Prepare the match for the rule
		EObject rule12_sel = root.eContents().get(1).eContents().get(20);;
		EObject rule12_tgt = root.eContents().get(1).eContents().get(10);
		unitApplication.setParameterValue(SELECTED, rule12_sel);
		unitApplication.setParameterValue(OLD_TARGET, rule12_tgt);

		// Apply the original rule
		long rule12_start = System.currentTimeMillis();
		boolean rule12_b = unitApplication.execute(null);
		long rule12_stop = System.currentTimeMillis();
		
		// Calculate the time
		exeTime = rule12_stop - rule12_start;
		System.out.println("- The application of original rule: " + ruleName + " Output is: " + rule12_b);
		System.out.println("- The rule application took: " + exeTime + " ms");
		printInfo=ruleName+", "+rule12_b+", "+  exeTime + " ms";
		System.out.println("=================================================================================================");
	}

}
