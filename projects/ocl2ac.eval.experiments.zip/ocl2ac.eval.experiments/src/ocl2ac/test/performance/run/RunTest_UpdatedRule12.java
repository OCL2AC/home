package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_UpdatedRule12 {

	private	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	private static final String OLD_TARGET = "OldTarget";
	private static final String SELECTED = "Selected";
	
	public static String ruleName = "rule12";
    public static String INSTANCE_FILE_PATH_NAME = null; 
    public static EObject root =null;
    public static String printInfo=null;

	public static String fileDirPathName = Configure.evalUpdatedRuleDirPathName;

	public static void main(String[] args) {
		printInfo=null;
		String newline = System.lineSeparator();

		// Load the model
		if (INSTANCE_FILE_PATH_NAME == null) INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
		Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
		 root = (EObject) resource.getContents().get(0);
		
		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The models are initialized. The model size: "+size);
		System.out.println("=================================================================================================");
	
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule12Updated, ruleName, root);
		
		// Prepare the match for the rule
		EObject rule12_sel = root.eContents().get(1).eContents().get(20);;
		EObject rule12_tgt = root.eContents().get(1).eContents().get(10);
		unitApplication.setParameterValue(SELECTED, rule12_sel);
		unitApplication.setParameterValue(OLD_TARGET, rule12_tgt);
		
		// Apply the updated rule
		long start = System.currentTimeMillis();
		boolean ruleAppRes = unitApplication.execute(null);
		long stop = System.currentTimeMillis();
		
		//Calculate the needed time
		long rule12_dif = stop - start;
		System.out.println("- The application of updated rule: " + ruleName + " Output is: " + ruleAppRes);
		System.out.println("- The rule application took: " + rule12_dif + " ms");
		printInfo=ruleName+", "+ruleAppRes+", "+  rule12_dif + " ms";
		System.out.println("=================================================================================================");
		
		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_UpdatedRule_" + ruleName;
		nas.text.append("modelSize_" + size + newline);
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);
	}
}
