package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule07EMFVal {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
	private static final String DASHPREFIX = "- ";
	
	public static EObject root = null;
	public static String printInfo = null;
	public static String INSTANCE_FILE_PATH_NAME = null;
    public static String fileDirPathName = Configure.evalRuleEMFDirPathName;

	public static void main(String[] args) {

		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}

		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
		System.out.println("=================================================================================================");

		// Apply the original rule
		RunTest_Rule07.root = root;
		RunTest_Rule07.main(null);
		String newline = System.lineSeparator();
		printInfo = DASHPREFIX + RunTest_Rule07.printInfo + newline;

		// Validate using the EMF validator
		RunTest_EMFValidator.root = root;
		RunTest_EMFValidator.main(null);
		printInfo += DASHPREFIX + RunTest_EMFValidator.printInfo + newline;
		long sum = RunTest_Rule07.exeTime + RunTest_EMFValidator.exeTime;
		printInfo += DASHPREFIX + RunTest_Rule07.exeTime + "+" + RunTest_EMFValidator.exeTime + "=" + sum + newline;
		System.out.println(printInfo);

		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_Rule_" + RunTest_Rule07.ruleName;
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);
	}

}
