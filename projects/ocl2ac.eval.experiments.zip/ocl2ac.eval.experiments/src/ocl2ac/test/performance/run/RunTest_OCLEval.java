package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;
import ocl2ac.test.performance.core.OCLInterpreter;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_OCLEval {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
    public static EObject root =null;
    public static String printInfo=null;
    public static long exeTime=0;
	public static void main(String[] args) {
		printInfo=null;
	    exeTime=0;
	    
//		// Load the model
//	    if (root ==null){
//		Resource resource = NasEMFManager.loadModel(Configure.instanceFilePathName_00845, ePackageInstance);
//		root = (EObject) resource.getContents().get(0);
//		int size = NasHenshinManager.getModelSize(root);
//		System.out.println("The models are initialized. The model size: "+size);
//		System.out.println("=================================================================================================");
//		}

		// Check validity using the OCL interpreter
		Object oclEvalResult = OCLInterpreter.evaluateOCLonModel(root, ePackageInstance, Configure.oclasFilePathName);
		System.out.println("- The output of the OCL interpreter is: "+(Boolean)oclEvalResult);
		exeTime=OCLInterpreter.evaluationTime;
		System.out.println("- The OCL interpreter took: "+ exeTime+" ms" );
		printInfo=(Boolean)oclEvalResult+", "+exeTime+" ms";
		System.out.println("=================================================================================================");
	}

}
