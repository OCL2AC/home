package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.henshin.interpreter.UnitApplication;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule01 {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	
	private static final String NEW_TARGET = "NewTarget";
	private static final String SELECTED = "Selected";
	
	public static final  String ruleName = "rule01";
	public static String INSTANCE_FILE_PATH_NAME = null;	
	public static EObject root =null;
    public static String printInfo=null;
    public static long exeTime=0;
    		
	public static void main(String[] args) {
		printInfo=null;
		exeTime=0;
		
		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}
		
		// Get model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: "+size);
		System.out.println("=================================================================================================");
		
		// Prepare the Henshin interpreter
		UnitApplication unitApplication = NasHenshinManager.prepareUnitApplication(Configure.henshinFilePathName_Rule01, ruleName, root);
		
		// Prepare the match for the rule
		EObject rule01_src = root.eContents().get(1).eContents().get(20);
		EObject rule01_tgt = root.eContents().get(1).eContents().get(10);
		unitApplication.setParameterValue(SELECTED, rule01_src);
		unitApplication.setParameterValue(NEW_TARGET, rule01_tgt);
	
		// Apply the original rule
		long rule01_start = System.currentTimeMillis();
		boolean rule01_b = unitApplication.execute(null);
		long rule01_stop = System.currentTimeMillis();
		
		// Calculate the needed time
		exeTime = rule01_stop - rule01_start;
		System.out.println("- The application of the original rule: " + ruleName + " Output is: " + rule01_b);
		System.out.println("- The rule application took: " + exeTime + " ms");
		printInfo=ruleName+", "+rule01_b+", "+  exeTime + " ms";
		System.out.println("=================================================================================================");
	}

}
