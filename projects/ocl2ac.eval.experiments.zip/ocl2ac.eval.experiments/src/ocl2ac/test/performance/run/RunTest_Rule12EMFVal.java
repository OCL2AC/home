package ocl2ac.test.performance.run;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import MagicDrawStatechartsEffective.MagicDrawStatechartsEffectivePackage;
import nas.core.NasEMFManager;
import nas.core.NasFileManager;
import nas.core.NasHenshinManager;
import ocl2ac.configure.Configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class RunTest_Rule12EMFVal {

	static MagicDrawStatechartsEffectivePackage ePackageInstance = MagicDrawStatechartsEffectivePackage.eINSTANCE;
	public static EObject root = null;
	public static String printInfo = null;
	public static String INSTANCE_FILE_PATH_NAME = null;
	private static final String DASHPREFIX = "- ";
	public static boolean saveSeparately = true;
	public static boolean onSpecificMatch = true;
    public static String fileDirPathName = Configure.evalRuleEMFDirPathName;

	public static void main(String[] args) {

		// Load the model
		if (root == null) {
			if (INSTANCE_FILE_PATH_NAME == null)
				INSTANCE_FILE_PATH_NAME = Configure.instanceFilePathName_00845;
			Resource resource = NasEMFManager.loadModel(INSTANCE_FILE_PATH_NAME, ePackageInstance);
			root = (EObject) resource.getContents().get(0);
			System.out.println("The models are initialized.");
		}

		// Get the model size
		int size = NasHenshinManager.getModelSize(root);
		System.out.println("The model size: " + size);
		System.out.println(
				"=================================================================================================");

		// Apply the original rule
		RunTest_Rule12.root = root;
		RunTest_Rule12.main(null);
		String newline = System.lineSeparator();
		printInfo = DASHPREFIX + RunTest_Rule12.printInfo + newline;

		// Validate using the EMF validator
		RunTest_EMFValidator.root = root;
		RunTest_EMFValidator.main(null);
		printInfo += DASHPREFIX + RunTest_EMFValidator.printInfo + newline;
		
		// Calculate the sum
		long sum = RunTest_Rule12.exeTime + RunTest_EMFValidator.exeTime;
		printInfo += DASHPREFIX + RunTest_Rule12.exeTime + "+" + RunTest_EMFValidator.exeTime + "=" + sum + newline;
		System.out.println(printInfo);

		// Save the result
		NasFileManager nas = new NasFileManager();
		String fileName = "modelSize_" + size + "_Rule_" + RunTest_Rule12.ruleName;
		nas.text.append(printInfo);
		nas.saveFile(fileDirPathName, fileName);
	}

}
