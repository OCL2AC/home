package ocl2ac.test.performance.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.util.EcoreUtil;

import nas.core.NasOCLManager;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class OCLInterpreter {

	public static long evaluationTime = 0;

	public static Object evaluateOCLonModel(EObject root, EPackage typeModel, String oclasFilePathName) {
		evaluationTime = 0;
		List<EObject> modelAsList = new ArrayList<EObject>();
		root.eAllContents().forEachRemaining(modelAsList::add);
		HashMap<EClass, ArrayList<String>> mpConstraintsInfo = NasOCLManager.getConstraintsInfo(oclasFilePathName,
				typeModel);

		Iterator it = mpConstraintsInfo.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			ArrayList<String> oclExpressions = (ArrayList<String>) pair.getValue();
			EClass contextType = (EClass) pair.getKey();
			// load context
			Collection<Object> objectContexts = EcoreUtil.getObjectsByType(modelAsList, contextType);

			for (Object o : objectContexts) {
				for (String expression : oclExpressions) {
					EObject context = (EObject) o;

					// Calculate the evaluation time for each one separately
					long start = System.currentTimeMillis();
					Object evaluateOCLOnContextObject = NasOCLManager.evaluateOCLOnContextObject(context, expression);
					long end = System.currentTimeMillis();
					long dif = end - start;

					// Calculate the total time
					evaluationTime += dif;

					if (evaluateOCLOnContextObject instanceof Boolean) {
						boolean b = (boolean) evaluateOCLOnContextObject;
						if (b == false)
							return false;
					} else {
						System.err.println(evaluateOCLOnContextObject);
						return null;
					}
				}
			}
		}
		return true;
	}

}
