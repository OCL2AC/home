package ocl2ac.configure;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class Configure {

	// The projectPathName is the field that has to be set by you regarding the path of the
	// project on your PC
	public static String projectPathName = "D:/tools/ws/ocl2ac.eval.experiments"; // this path is given as an example

	// integrator
	public static String inputRulesFolderPathName = projectPathName + "/integrator/inputRules";
	public static String outputRulesFolderPathName = projectPathName + "/integrator/outputRules";
	public static String nestedConstraintFilePathName = projectPathName
			+ "/model/MagicDrawStatechartsEffectiveConstraints.nestedconstraintmodel";
	public static String oclasFilePathName = projectPathName + "/model/MagicDrawStatechartsEffective.ecore.oclas";

	// The path of the main folder for the performance test
	public static String evalDirPathName = projectPathName + "/eval";
	public static String evalRuleEMFDirPathName = evalDirPathName + "/ResEvalRuleEMF";
	public static String evalRuleOCLDirPathName = evalDirPathName + "/ResEvalRuleOCL";
	public static String evalUpdatedRuleDirPathName = evalDirPathName + "/ResEvalUpdatedRule";

	// Paths of the original rules
	public static String henshinFilePathName_Rule00 = evalDirPathName + "/rule00.henshin";
	public static String henshinFilePathName_Rule01 = evalDirPathName + "/rule01.henshin";
	public static String henshinFilePathName_Rule03 = evalDirPathName + "/rule03.henshin";
	public static String henshinFilePathName_Rule07 = evalDirPathName + "/rule07.henshin";
	public static String henshinFilePathName_Rule11 = evalDirPathName + "/rule11.henshin";
	public static String henshinFilePathName_Rule12 = evalDirPathName + "/rule12.henshin";

	// Paths of the updated rules
	public static String henshinFilePathName_Rule00Updated = evalDirPathName + "/rule00_updated.henshin";
	public static String henshinFilePathName_Rule01Updated = evalDirPathName + "/rule01_updated.henshin";
	public static String henshinFilePathName_Rule03Updated = evalDirPathName + "/rule03_updated.henshin";
	public static String henshinFilePathName_Rule07Updated = evalDirPathName + "/rule07_updated.henshin";
	public static String henshinFilePathName_Rule11Updated = evalDirPathName + "/rule11_updated.henshin";
	public static String henshinFilePathName_Rule12Updated = evalDirPathName + "/rule12_updated.henshin";

	// Paths of the test models
	public static String instanceFilePathName_00845 = evalDirPathName + "/My_00845.magicdrawstatechartseffective";
	public static String instanceFilePathName_01686 = evalDirPathName + "/My_01686.magicdrawstatechartseffective";
	public static String instanceFilePathName_03368 = evalDirPathName + "/My_03368.magicdrawstatechartseffective";
	public static String instanceFilePathName_06732 = evalDirPathName + "/My_06732.magicdrawstatechartseffective";
	public static String instanceFilePathName_10096 = evalDirPathName + "/My_10096.magicdrawstatechartseffective";
	public static String instanceFilePathName_13460 = evalDirPathName + "/My_13460.magicdrawstatechartseffective";
	public static String instanceFilePathName_16824 = evalDirPathName + "/My_16824.magicdrawstatechartseffective";
}
