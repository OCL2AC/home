package nas.core;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * 
 * @author Nassarn (Nebras Nassar)
 *
 */
public class NasFileManager {

	private static final String TXT = ".txt";
	public StringBuffer text;

	public NasFileManager() {
		text = new StringBuffer();
	}

	/**
	 * 
	 * @param pathDir
	 * @param fileName
	 */
	public void saveFile(String pathDir, String fileName) {
		String folderPathName = pathDir;
		String formal = "yyyyMMdd";
		SimpleDateFormat sdf = new SimpleDateFormat(formal);
		Date date = new GregorianCalendar().getTime();
		String outputFilePathName = folderPathName.concat("\\" + fileName + "_" + sdf.format(date) + TXT);
		File file = new File(outputFilePathName);
		Writer writer = null;
		try {
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
			writer.write(text.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
