package nas.core;

import org.eclipse.emf.henshin.model.And;
import org.eclipse.emf.henshin.model.HenshinFactory;
import org.eclipse.emf.henshin.model.Rule;

import de.unimarburg.swt.nestedcondition.henshin.Integrator;
import de.unimarburg.swt.nestedcondition.henshin.Lefter;
import nestedcondition.NestedConstraint;

/**
 * 
 *  @author Nassarn (Nebras Nassar)
 *
 */
public class NasIntegratorManager {

	public static long evaluationTime = 0;

	/**
	 * 
	 * @param constraint
	 * @param rule
	 */
	public void integrateAndleft(NestedConstraint constraint, Rule rule) {
		if (rule != null) {

			// Calculate the integration time
			long start = System.currentTimeMillis();

			Integrator integrator = new Integrator(constraint, rule);
			integrator.integrate();
			org.eclipse.emf.henshin.model.Formula existingFormula = rule.getLhs().getFormula();
			Lefter lefter = new Lefter(rule);
			lefter.left();
			if (existingFormula != null) {
				And henshinAnd = HenshinFactory.eINSTANCE.createAnd();
				henshinAnd.setLeft(existingFormula);
				henshinAnd.setRight(rule.getLhs().getFormula());
				rule.getLhs().setFormula(henshinAnd);
			}

			long stop = System.currentTimeMillis();
			evaluationTime = stop - start;
		}
	}
}
