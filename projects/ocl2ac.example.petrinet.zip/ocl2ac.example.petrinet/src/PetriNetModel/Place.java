/**
 */
package PetriNetModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Place</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.Place#getPreArc <em>Pre Arc</em>}</li>
 *   <li>{@link PetriNetModel.Place#getToken <em>Token</em>}</li>
 *   <li>{@link PetriNetModel.Place#getPostArc <em>Post Arc</em>}</li>
 * </ul>
 *
 * @see PetriNetModel.PetriNetModelPackage#getPlace()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='Example11'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot Example11='self.preArc -> notEmpty() or self.postArc -> notEmpty()'"
 * @generated
 */
public interface Place extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Pre Arc</b></em>' reference list.
	 * The list contents are of type {@link PetriNetModel.TPArc}.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.TPArc#getDst <em>Dst</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre Arc</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre Arc</em>' reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPlace_PreArc()
	 * @see PetriNetModel.TPArc#getDst
	 * @model opposite="dst"
	 * @generated
	 */
	EList<TPArc> getPreArc();

	/**
	 * Returns the value of the '<em><b>Token</b></em>' containment reference list.
	 * The list contents are of type {@link PetriNetModel.Token}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Token</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Token</em>' containment reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPlace_Token()
	 * @model containment="true"
	 * @generated
	 */
	EList<Token> getToken();

	/**
	 * Returns the value of the '<em><b>Post Arc</b></em>' reference list.
	 * The list contents are of type {@link PetriNetModel.PTArc}.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.PTArc#getSrc <em>Src</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post Arc</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post Arc</em>' reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPlace_PostArc()
	 * @see PetriNetModel.PTArc#getSrc
	 * @model opposite="src"
	 * @generated
	 */
	EList<PTArc> getPostArc();

} // Place
