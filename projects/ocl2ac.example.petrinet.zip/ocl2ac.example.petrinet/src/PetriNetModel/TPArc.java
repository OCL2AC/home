/**
 */
package PetriNetModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TP Arc</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.TPArc#getDst <em>Dst</em>}</li>
 *   <li>{@link PetriNetModel.TPArc#getSrc <em>Src</em>}</li>
 * </ul>
 *
 * @see PetriNetModel.PetriNetModelPackage#getTPArc()
 * @model
 * @generated
 */
public interface TPArc extends Arc {
	/**
	 * Returns the value of the '<em><b>Dst</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.Place#getPreArc <em>Pre Arc</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dst</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dst</em>' reference.
	 * @see #setDst(Place)
	 * @see PetriNetModel.PetriNetModelPackage#getTPArc_Dst()
	 * @see PetriNetModel.Place#getPreArc
	 * @model opposite="preArc" required="true"
	 * @generated
	 */
	Place getDst();

	/**
	 * Sets the value of the '{@link PetriNetModel.TPArc#getDst <em>Dst</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dst</em>' reference.
	 * @see #getDst()
	 * @generated
	 */
	void setDst(Place value);

	/**
	 * Returns the value of the '<em><b>Src</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.Transition#getPostArc <em>Post Arc</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Src</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Src</em>' reference.
	 * @see #setSrc(Transition)
	 * @see PetriNetModel.PetriNetModelPackage#getTPArc_Src()
	 * @see PetriNetModel.Transition#getPostArc
	 * @model opposite="postArc" required="true"
	 * @generated
	 */
	Transition getSrc();

	/**
	 * Sets the value of the '{@link PetriNetModel.TPArc#getSrc <em>Src</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Src</em>' reference.
	 * @see #getSrc()
	 * @generated
	 */
	void setSrc(Transition value);

} // TPArc
