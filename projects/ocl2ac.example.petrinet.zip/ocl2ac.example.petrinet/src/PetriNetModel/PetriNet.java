/**
 */
package PetriNetModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Petri Net</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.PetriNet#getTransition <em>Transition</em>}</li>
 *   <li>{@link PetriNetModel.PetriNet#getArc <em>Arc</em>}</li>
 *   <li>{@link PetriNetModel.PetriNet#getPlace <em>Place</em>}</li>
 * </ul>
 *
 * @see PetriNetModel.PetriNetModelPackage#getPetriNet()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='Example10b Example12 Example13a Example13b Example13c Example13d Example15'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot Example10b='self.transition -> forAll(t|t.preArc -> notEmpty() or t.postArc -> notEmpty())' Example12='self.place -> forAll(p1|self.place -> forAll(p2|p1 <> p2 implies p1.name <> p2.name))' Example13a='self.place -> exists(p|p.token -> notEmpty())' Example13b='self.place -> select(p|p.token -> notEmpty()) -> notEmpty()' Example13c='self.place -> collect(p|p.token) -> notEmpty()' Example13d='Token.allInstances() -> notEmpty()' Example15='self.place -> size() >= 2'"
 * @generated
 */
public interface PetriNet extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
	 * The list contents are of type {@link PetriNetModel.Transition}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transition</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' containment reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPetriNet_Transition()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Transition> getTransition();

	/**
	 * Returns the value of the '<em><b>Arc</b></em>' containment reference list.
	 * The list contents are of type {@link PetriNetModel.Arc}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Arc</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Arc</em>' containment reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPetriNet_Arc()
	 * @model containment="true"
	 * @generated
	 */
	EList<Arc> getArc();

	/**
	 * Returns the value of the '<em><b>Place</b></em>' containment reference list.
	 * The list contents are of type {@link PetriNetModel.Place}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Place</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Place</em>' containment reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getPetriNet_Place()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Place> getPlace();

} // PetriNet
