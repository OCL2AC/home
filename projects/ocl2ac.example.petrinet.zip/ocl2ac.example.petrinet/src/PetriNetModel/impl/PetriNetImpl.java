/**
 */
package PetriNetModel.impl;

import PetriNetModel.Arc;
import PetriNetModel.PetriNet;
import PetriNetModel.PetriNetModelPackage;
import PetriNetModel.Place;
import PetriNetModel.Transition;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Petri Net</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.impl.PetriNetImpl#getTransition <em>Transition</em>}</li>
 *   <li>{@link PetriNetModel.impl.PetriNetImpl#getArc <em>Arc</em>}</li>
 *   <li>{@link PetriNetModel.impl.PetriNetImpl#getPlace <em>Place</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PetriNetImpl extends NamedElementImpl implements PetriNet {
	/**
	 * The cached value of the '{@link #getTransition() <em>Transition</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransition()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transition;

	/**
	 * The cached value of the '{@link #getArc() <em>Arc</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArc()
	 * @generated
	 * @ordered
	 */
	protected EList<Arc> arc;

	/**
	 * The cached value of the '{@link #getPlace() <em>Place</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlace()
	 * @generated
	 * @ordered
	 */
	protected EList<Place> place;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PetriNetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PetriNetModelPackage.Literals.PETRI_NET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransition() {
		if (transition == null) {
			transition = new EObjectContainmentEList<Transition>(Transition.class, this, PetriNetModelPackage.PETRI_NET__TRANSITION);
		}
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Arc> getArc() {
		if (arc == null) {
			arc = new EObjectContainmentEList<Arc>(Arc.class, this, PetriNetModelPackage.PETRI_NET__ARC);
		}
		return arc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Place> getPlace() {
		if (place == null) {
			place = new EObjectContainmentEList<Place>(Place.class, this, PetriNetModelPackage.PETRI_NET__PLACE);
		}
		return place;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PetriNetModelPackage.PETRI_NET__TRANSITION:
				return ((InternalEList<?>)getTransition()).basicRemove(otherEnd, msgs);
			case PetriNetModelPackage.PETRI_NET__ARC:
				return ((InternalEList<?>)getArc()).basicRemove(otherEnd, msgs);
			case PetriNetModelPackage.PETRI_NET__PLACE:
				return ((InternalEList<?>)getPlace()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PetriNetModelPackage.PETRI_NET__TRANSITION:
				return getTransition();
			case PetriNetModelPackage.PETRI_NET__ARC:
				return getArc();
			case PetriNetModelPackage.PETRI_NET__PLACE:
				return getPlace();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PetriNetModelPackage.PETRI_NET__TRANSITION:
				getTransition().clear();
				getTransition().addAll((Collection<? extends Transition>)newValue);
				return;
			case PetriNetModelPackage.PETRI_NET__ARC:
				getArc().clear();
				getArc().addAll((Collection<? extends Arc>)newValue);
				return;
			case PetriNetModelPackage.PETRI_NET__PLACE:
				getPlace().clear();
				getPlace().addAll((Collection<? extends Place>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PetriNetModelPackage.PETRI_NET__TRANSITION:
				getTransition().clear();
				return;
			case PetriNetModelPackage.PETRI_NET__ARC:
				getArc().clear();
				return;
			case PetriNetModelPackage.PETRI_NET__PLACE:
				getPlace().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PetriNetModelPackage.PETRI_NET__TRANSITION:
				return transition != null && !transition.isEmpty();
			case PetriNetModelPackage.PETRI_NET__ARC:
				return arc != null && !arc.isEmpty();
			case PetriNetModelPackage.PETRI_NET__PLACE:
				return place != null && !place.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PetriNetImpl
