/**
 */
package PetriNetModel.impl;

import PetriNetModel.PTArc;
import PetriNetModel.PetriNetModelPackage;
import PetriNetModel.Place;
import PetriNetModel.TPArc;
import PetriNetModel.Token;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Place</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.impl.PlaceImpl#getPreArc <em>Pre Arc</em>}</li>
 *   <li>{@link PetriNetModel.impl.PlaceImpl#getToken <em>Token</em>}</li>
 *   <li>{@link PetriNetModel.impl.PlaceImpl#getPostArc <em>Post Arc</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PlaceImpl extends NamedElementImpl implements Place {
	/**
	 * The cached value of the '{@link #getPreArc() <em>Pre Arc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreArc()
	 * @generated
	 * @ordered
	 */
	protected EList<TPArc> preArc;

	/**
	 * The cached value of the '{@link #getToken() <em>Token</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToken()
	 * @generated
	 * @ordered
	 */
	protected EList<Token> token;

	/**
	 * The cached value of the '{@link #getPostArc() <em>Post Arc</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostArc()
	 * @generated
	 * @ordered
	 */
	protected EList<PTArc> postArc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlaceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PetriNetModelPackage.Literals.PLACE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TPArc> getPreArc() {
		if (preArc == null) {
			preArc = new EObjectWithInverseResolvingEList<TPArc>(TPArc.class, this, PetriNetModelPackage.PLACE__PRE_ARC, PetriNetModelPackage.TP_ARC__DST);
		}
		return preArc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Token> getToken() {
		if (token == null) {
			token = new EObjectContainmentEList<Token>(Token.class, this, PetriNetModelPackage.PLACE__TOKEN);
		}
		return token;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PTArc> getPostArc() {
		if (postArc == null) {
			postArc = new EObjectWithInverseResolvingEList<PTArc>(PTArc.class, this, PetriNetModelPackage.PLACE__POST_ARC, PetriNetModelPackage.PT_ARC__SRC);
		}
		return postArc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getPreArc()).basicAdd(otherEnd, msgs);
			case PetriNetModelPackage.PLACE__POST_ARC:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getPostArc()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				return ((InternalEList<?>)getPreArc()).basicRemove(otherEnd, msgs);
			case PetriNetModelPackage.PLACE__TOKEN:
				return ((InternalEList<?>)getToken()).basicRemove(otherEnd, msgs);
			case PetriNetModelPackage.PLACE__POST_ARC:
				return ((InternalEList<?>)getPostArc()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				return getPreArc();
			case PetriNetModelPackage.PLACE__TOKEN:
				return getToken();
			case PetriNetModelPackage.PLACE__POST_ARC:
				return getPostArc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				getPreArc().clear();
				getPreArc().addAll((Collection<? extends TPArc>)newValue);
				return;
			case PetriNetModelPackage.PLACE__TOKEN:
				getToken().clear();
				getToken().addAll((Collection<? extends Token>)newValue);
				return;
			case PetriNetModelPackage.PLACE__POST_ARC:
				getPostArc().clear();
				getPostArc().addAll((Collection<? extends PTArc>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				getPreArc().clear();
				return;
			case PetriNetModelPackage.PLACE__TOKEN:
				getToken().clear();
				return;
			case PetriNetModelPackage.PLACE__POST_ARC:
				getPostArc().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PetriNetModelPackage.PLACE__PRE_ARC:
				return preArc != null && !preArc.isEmpty();
			case PetriNetModelPackage.PLACE__TOKEN:
				return token != null && !token.isEmpty();
			case PetriNetModelPackage.PLACE__POST_ARC:
				return postArc != null && !postArc.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PlaceImpl
