/**
 */
package PetriNetModel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PetriNetModel.Transition#getPreArc <em>Pre Arc</em>}</li>
 *   <li>{@link PetriNetModel.Transition#getPostArc <em>Post Arc</em>}</li>
 * </ul>
 *
 * @see PetriNetModel.PetriNetModelPackage#getTransition()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='Example9 Example10a'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot Example9='self.name <> \'\'' Example10a='self.preArc -> notEmpty() or self.postArc -> notEmpty()'"
 * @generated
 */
public interface Transition extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Pre Arc</b></em>' reference list.
	 * The list contents are of type {@link PetriNetModel.PTArc}.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.PTArc#getDst <em>Dst</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre Arc</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre Arc</em>' reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getTransition_PreArc()
	 * @see PetriNetModel.PTArc#getDst
	 * @model opposite="dst"
	 * @generated
	 */
	EList<PTArc> getPreArc();

	/**
	 * Returns the value of the '<em><b>Post Arc</b></em>' reference list.
	 * The list contents are of type {@link PetriNetModel.TPArc}.
	 * It is bidirectional and its opposite is '{@link PetriNetModel.TPArc#getSrc <em>Src</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post Arc</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post Arc</em>' reference list.
	 * @see PetriNetModel.PetriNetModelPackage#getTransition_PostArc()
	 * @see PetriNetModel.TPArc#getSrc
	 * @model opposite="src"
	 * @generated
	 */
	EList<TPArc> getPostArc();

} // Transition
