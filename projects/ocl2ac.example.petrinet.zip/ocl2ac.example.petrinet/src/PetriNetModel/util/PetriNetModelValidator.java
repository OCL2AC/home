/**
 */
package PetriNetModel.util;

import PetriNetModel.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see PetriNetModel.PetriNetModelPackage
 * @generated
 */
public class PetriNetModelValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final PetriNetModelValidator INSTANCE = new PetriNetModelValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "PetriNetModel";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PetriNetModelValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return PetriNetModelPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case PetriNetModelPackage.NAMED_ELEMENT:
				return validateNamedElement((NamedElement)value, diagnostics, context);
			case PetriNetModelPackage.ARC:
				return validateArc((Arc)value, diagnostics, context);
			case PetriNetModelPackage.PETRI_NET:
				return validatePetriNet((PetriNet)value, diagnostics, context);
			case PetriNetModelPackage.TRANSITION:
				return validateTransition((Transition)value, diagnostics, context);
			case PetriNetModelPackage.PT_ARC:
				return validatePTArc((PTArc)value, diagnostics, context);
			case PetriNetModelPackage.TP_ARC:
				return validateTPArc((TPArc)value, diagnostics, context);
			case PetriNetModelPackage.PLACE:
				return validatePlace((Place)value, diagnostics, context);
			case PetriNetModelPackage.TOKEN:
				return validateToken((Token)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNamedElement(NamedElement namedElement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(namedElement, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateArc(Arc arc, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(arc, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(arc, diagnostics, context);
		if (result || diagnostics != null) result &= validateArc_Example14(arc, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the Example14 constraint of '<em>Arc</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ARC__EXAMPLE14__EEXPRESSION = "self.weight >= 1";

	/**
	 * Validates the Example14 constraint of '<em>Arc</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateArc_Example14(Arc arc, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.ARC,
				 arc,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example14",
				 ARC__EXAMPLE14__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(petriNet, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example10b(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example12(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example13a(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example13b(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example13c(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example13d(petriNet, diagnostics, context);
		if (result || diagnostics != null) result &= validatePetriNet_Example15(petriNet, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the Example10b constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE10B__EEXPRESSION = "self.transition -> forAll(t|t.preArc -> notEmpty() or t.postArc -> notEmpty())";

	/**
	 * Validates the Example10b constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example10b(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example10b",
				 PETRI_NET__EXAMPLE10B__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example12 constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE12__EEXPRESSION = "self.place -> forAll(p1|self.place -> forAll(p2|p1 <> p2 implies p1.name <> p2.name))";

	/**
	 * Validates the Example12 constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example12(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example12",
				 PETRI_NET__EXAMPLE12__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example13a constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE13A__EEXPRESSION = "self.place -> exists(p|p.token -> notEmpty())";

	/**
	 * Validates the Example13a constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example13a(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example13a",
				 PETRI_NET__EXAMPLE13A__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example13b constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE13B__EEXPRESSION = "self.place -> select(p|p.token -> notEmpty()) -> notEmpty()";

	/**
	 * Validates the Example13b constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example13b(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example13b",
				 PETRI_NET__EXAMPLE13B__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example13c constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE13C__EEXPRESSION = "self.place -> collect(p|p.token) -> notEmpty()";

	/**
	 * Validates the Example13c constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example13c(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example13c",
				 PETRI_NET__EXAMPLE13C__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example13d constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE13D__EEXPRESSION = "Token.allInstances() -> notEmpty()";

	/**
	 * Validates the Example13d constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example13d(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example13d",
				 PETRI_NET__EXAMPLE13D__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example15 constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PETRI_NET__EXAMPLE15__EEXPRESSION = "self.place -> size() >= 2";

	/**
	 * Validates the Example15 constraint of '<em>Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePetriNet_Example15(PetriNet petriNet, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PETRI_NET,
				 petriNet,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example15",
				 PETRI_NET__EXAMPLE15__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransition(Transition transition, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(transition, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validateTransition_Example9(transition, diagnostics, context);
		if (result || diagnostics != null) result &= validateTransition_Example10a(transition, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the Example9 constraint of '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TRANSITION__EXAMPLE9__EEXPRESSION = "self.name <> ''";

	/**
	 * Validates the Example9 constraint of '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransition_Example9(Transition transition, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.TRANSITION,
				 transition,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example9",
				 TRANSITION__EXAMPLE9__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Example10a constraint of '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String TRANSITION__EXAMPLE10A__EEXPRESSION = "self.preArc -> notEmpty() or self.postArc -> notEmpty()";

	/**
	 * Validates the Example10a constraint of '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransition_Example10a(Transition transition, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.TRANSITION,
				 transition,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example10a",
				 TRANSITION__EXAMPLE10A__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePTArc(PTArc ptArc, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(ptArc, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(ptArc, diagnostics, context);
		if (result || diagnostics != null) result &= validateArc_Example14(ptArc, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTPArc(TPArc tpArc, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(tpArc, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(tpArc, diagnostics, context);
		if (result || diagnostics != null) result &= validateArc_Example14(tpArc, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePlace(Place place, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(place, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(place, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(place, diagnostics, context);
		if (result || diagnostics != null) result &= validatePlace_Example11(place, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the Example11 constraint of '<em>Place</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PLACE__EXAMPLE11__EEXPRESSION = "self.preArc -> notEmpty() or self.postArc -> notEmpty()";

	/**
	 * Validates the Example11 constraint of '<em>Place</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePlace_Example11(Place place, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(PetriNetModelPackage.Literals.PLACE,
				 place,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Example11",
				 PLACE__EXAMPLE11__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateToken(Token token, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(token, diagnostics, context);
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //PetriNetModelValidator
