/**
 */
package Statechart;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Final State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A special kind of state signifying that the enclosing region is completed. If the enclosing region is directly contained in a state machine and all other regions in the state machine also are completed, then it means that the entire state machine is completed.
 * <!-- end-model-doc -->
 *
 *
 * @see Statechart.StatechartPackage#getFinalState()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='no_outgoing_transitions no_regions no_entry_behavior no_exist_behavior cannot_reference_submachine no_state_behavior'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot no_outgoing_transitions='self.outgoing->isEmpty()' no_regions='self.region->size() = 0' no_entry_behavior='self.enty->isEmpty()' no_exist_behavior='self.exit->isEmpty()' cannot_reference_submachine='self.submachine->isEmpty()' no_state_behavior='self.doActivity->isEmpty()'"
 * @generated
 */
public interface FinalState extends State {
} // FinalState
