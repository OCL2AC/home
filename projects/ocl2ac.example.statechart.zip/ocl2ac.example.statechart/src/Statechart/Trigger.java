/**
 */
package Statechart;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Statechart.StatechartPackage#getTrigger()
 * @model
 * @generated
 */
public interface Trigger extends EObject {
} // Trigger
