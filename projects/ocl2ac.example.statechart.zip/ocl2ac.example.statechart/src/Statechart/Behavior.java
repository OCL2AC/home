/**
 */
package Statechart;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Statechart.StatechartPackage#getBehavior()
 * @model
 * @generated
 */
public interface Behavior extends EObject {
} // Behavior
